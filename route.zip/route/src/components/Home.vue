<template>
    <div>
        <h2>Home page</h2>
        <hr>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aspernatur esse voluptatum illum fugit velit. Laborum quas reprehenderit, sint deserunt earum laboriosam fuga, aperiam molestiae quae assumenda exercitationem accusamus velit quia? Nobis adipisci fugit ratione fugiat architecto accusamus quisquam nulla unde.</p>
        
    </div>
</template>