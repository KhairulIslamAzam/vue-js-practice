<template>
    <h2>Customer</h2>
</template>