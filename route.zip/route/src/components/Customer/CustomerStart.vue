<template>
    <div>
        <p>Please select a customer</p>
        <hr>
        <ul class="list-group">
            <li class="list-group-item" style="cursor: pointer">Customer 1</li>
            <li class="list-group-item" style="cursor: pointer">Customer 2</li>
            <li class="list-group-item" style="cursor: pointer">Customer 3</li>
        </ul>
    </div>
</template>