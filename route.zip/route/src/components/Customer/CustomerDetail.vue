<template>
    <h2>Customer Detail</h2>
</template>